import React from 'react';
import Adapter from 'enzyme-adapter-react-16';
import { configure, shallow } from 'enzyme';
import { mount } from 'enzyme';
import { MemoryRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';

import App from './App';
import Layout from './Layouts/Layout';
import { AddPatientPage } from './Pages';
import HospitalNavbar from './Layouts/HospitalNavbar';

configure({adapter: new Adapter()});

const mockStore = configureStore([]);

describe('<App />', () => {
  let store;
 
  beforeEach(() => {
    store = mockStore({
      alert: {},
        authentication: {
            loggedIn: true,
            user: {
                "firstName": "Manu",
                "lastName": "Murali",
                "username": "manumurali",
                "password": "password",
                "id": 2
              }
        }
    });
  });

  it('should render Layout component', () => {
    const wrapper = shallow(<App />);
    expect(wrapper.find(Layout)).toHaveLength(1);
  });
  
})