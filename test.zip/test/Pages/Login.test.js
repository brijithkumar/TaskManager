import React from 'react';
import { mount, shallow, configure } from 'enzyme';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import configureStore from 'redux-mock-store';
import Adapter from 'enzyme-adapter-react-16';
import { LoginPage } from './LoginPage';

configure({adapter: new Adapter()});

const initialState = {
        username: '',
        password: '',
        submitted: false,
        authentication: {
            loggingIn: false
        }
    };
const props = {
    loggingIn: false,
    login: jest.fn(),
    logout: jest.fn()
}
let store;
beforeEach(() => {
    const mockStore =configureMockStore([thunk]);
    store = mockStore(initialState);
})
describe('<LoginPage />', () => {
    it('username check', () => {
        let wrapper = shallow(<LoginPage store={store} />).dive();
        wrapper.find('input[type="text"]').simulate('change', {target: {
            name: 'username', value: 'testuser'
        }})
        expect(wrapper.state('username')).toEqual('testuser');
    })
    it('password check', () => {
        let wrapper = shallow(<LoginPage store={store} />).dive();
        wrapper.find('input[type="password"]').simulate('change', {target: {
            name: 'password', value: 'test'
        }})
        expect(wrapper.state('password')).toEqual('test');
    })
});

// describe('mount', () => {
    
//     it('InnerConnectConnected, with connect', () => {
//         const mockStore = configureStore([]);
//         const store = mockStore(initialState);
//         const wrapper = mount(<Provider store={store}>
//             <LoginPage />
//         </Provider>);
//         expect(wrapper.find('h2').length).toBe(1);
//         // expect(wrapper.find('h2').text())
//         //     .toBe('Login');
//     });
// });