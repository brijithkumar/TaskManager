import React from 'react';
import { connect } from 'react-redux';

import { Navbar, Nav } from 'react-bootstrap';

class BootstrapNavbar extends React.Component {

    render() {
        const { loggedIn } = this.props;
        return (
            <div>
                <div className="row">
                    <div className="col-md-12">
                        {/* <Router> */}
                            <Navbar bg="dark" variant="dark" expand="lg" sticky="top">
                                <Navbar.Brand href="#home" className="p-4">Hospital Management</Navbar.Brand>
                                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                                <Navbar.Collapse id="basic-navbar-nav">
                                    <Nav className="ml-auto">
                                        <Nav.Link href="/">{loggedIn ? 'Home' : 'Login'}</Nav.Link>
                                        {loggedIn && <Nav.Link href="/addPatient">Add Patient</Nav.Link>}
                                        {loggedIn && <Nav.Link href="/logout">Logout</Nav.Link>}
                                    </Nav>
                                </Navbar.Collapse>                                
                            </Navbar>
                            <br />
                            {/* <Switch>
                                <Route exact path="/">
                                    <HomePage />
                                </Route>
                                <Route path="/addPatient">
                                    <AddPatientPage />
                                </Route>
                                <Route path="/logout">
                                    <LoginPage />
                                </Route>
                            </Switch>
                        </Router> */}
                    </div>
                </div>
            </div>
        )
    }
}
function mapState(state) {
    const { loggedIn } = state.authentication;
    return { loggedIn };
}
export default connect(mapState)(BootstrapNavbar);