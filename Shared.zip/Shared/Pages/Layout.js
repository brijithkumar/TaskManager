import React from "react";

import BootstrapNavBar from '../BootstrapNavbar';

const Layout = props => {
  return (
    <>
      <BootstrapNavBar />
      <main>{props.children}</main>
    </>
  );
};
export default Layout;